//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// © 2016 and later: Unicode, Inc. and others.
// License & terms of use: http://www.unicode.org/copyright.html#License
// Corporation and others. All Rights Reserved.
// Copyright (c) 2001-2003 International Business Machines
// Corporation and others. All Rights Reserved.
// Used by LayoutSample.rc
//
#define IDM_FILE_NEWSAMPLE              40001
#define IDM_FILE_OPEN                   40002
#define IDM_FILE_CLOSE                  40003
#define IDM_FILE_EXIT                   40004
#define IDM_HELP_ABOUTLAYOUTSAMPLE      40005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
