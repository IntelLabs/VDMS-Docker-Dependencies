/* Used by security_compute_av. */
#define PROCESS__TRANSITION                       0x00000002UL
#define PROCESS__DYNTRANSITION                    0x00800000UL
