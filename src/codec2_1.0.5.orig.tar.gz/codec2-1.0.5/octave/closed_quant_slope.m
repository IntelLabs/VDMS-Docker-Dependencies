function b = closed_quant_slope(b)
  b(1) = max(0.5, b(1));
end
