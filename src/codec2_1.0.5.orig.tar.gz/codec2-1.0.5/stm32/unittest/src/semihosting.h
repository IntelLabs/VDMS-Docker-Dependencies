#ifndef SEMIHOSTING_H
#define SEMIHOSTING_H
extern int semihosting_init(void);

#endif // SEMIHOSTING_H

/* vi:set ts=4 et sts=4: */
