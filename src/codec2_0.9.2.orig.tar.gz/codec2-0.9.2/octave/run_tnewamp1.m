% Needed this to keep Travis happy, I guess on that version of
% Linux/Octave, octave functions can't be invoked from the command
% line, just scripts

tnewamp1("../build_linux/src/cq_ref")
