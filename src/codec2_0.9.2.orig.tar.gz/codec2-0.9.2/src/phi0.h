// phi0.h
#ifndef PHI0_H
#define PHI0_H

extern float phi0( float xf );

#endif
