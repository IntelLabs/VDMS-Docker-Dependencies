# Coded Modulation Library for codec2

The [CML library](http://www.iterativesolutions.com/Matlab.htm) is a set of Matlab/Octave functions, written in C but callable by Matlab/Octave. They are used by the codec2 project to support LDPC Octave simulations.

The codec2 project specific changes in this repo include:
1. Building without warnings of errors.
2. Support for OSX and Ubuntu.

Building:
```
$ make
```