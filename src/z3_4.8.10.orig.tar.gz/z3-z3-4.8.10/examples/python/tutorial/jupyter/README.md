# Jupyter version of the Z3 Python Tutorial.

Thanks to Peter Gragert, the Z3 tutorial guide is now available in the Jupyter notebook format. You can try it directly online from:

https://z3examples-nbjorner.notebooks.azure.com/j/notebooks/guide.ipynb
