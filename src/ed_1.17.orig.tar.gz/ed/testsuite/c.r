at the top
production in the earth, and that great law of our nature which must
constantly keep their effects equal, form the great difficulty that to
in the middle
after the middle
of this law which pervades all animated nature. No fancied equality, no
between middle/bottom
no anxiety about providing the means of subsistence for themselves and
at the bottom
