This natural inequality of the two powers of population and of
me appears insurmountable in the way to the perfectibility of society.
All other arguments are of slight and subordinate consideration in
comparison of this. I see no way by which man can escape from the weight
agrarian regulations in their utmost extent, could remove the pressure
of it even for a single century. And it appears, therefore, to be
decisive against the possible existence of a society, all the members of
