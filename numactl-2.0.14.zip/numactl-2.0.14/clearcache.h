void clearcache(unsigned char *mem, unsigned size);
