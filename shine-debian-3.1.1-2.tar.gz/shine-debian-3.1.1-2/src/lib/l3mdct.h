#ifndef shine_MDCT_H
#define shine_MDCT_H

void shine_mdct_initialise();
void shine_mdct_sub(shine_global_config *config, int stride);

#endif
